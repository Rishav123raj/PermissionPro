package com.example.permissionpro.model;

public enum Gender {
    MALE, FEMALE
}
