package com.example.permissionpro.service;

import org.springframework.http.ResponseEntity;

import com.example.permissionpro.payload.requests.ForgotPasswordRequest;
import com.example.permissionpro.payload.requests.LoginRequest;
import com.example.permissionpro.payload.requests.RegisterRequest;
import com.example.permissionpro.payload.requests.RegisterVerifyRequest;
import com.example.permissionpro.payload.requests.ResetPasswordRequest;
import com.example.permissionpro.payload.responses.RegisterResponse;

public interface AuthenticationService {
    ResponseEntity<RegisterResponse> registerUser(RegisterRequest registerRequest);
      ResponseEntity<?> verifyUserRegistration(RegisterVerifyRequest registerVerifyRequest);
      ResponseEntity<?> loginUser(LoginRequest loginRequest);
      ResponseEntity<?> resendOtp(ForgotPasswordRequest forgotPasswordRequest);
      ResponseEntity<?> verifyOtp(RegisterVerifyRequest registerVerifyRequest);
      ResponseEntity<?> resetPassword(ResetPasswordRequest resetPasswordRequest);
     ResponseEntity<?> myProfile(ForgotPasswordRequest forgotPasswordRequest);
}
