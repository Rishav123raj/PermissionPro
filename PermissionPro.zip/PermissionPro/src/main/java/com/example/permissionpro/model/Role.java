package com.example.permissionpro.model;

public enum Role {
    USER, ADMIN
}
