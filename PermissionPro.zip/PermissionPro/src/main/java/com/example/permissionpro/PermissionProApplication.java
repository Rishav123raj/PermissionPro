package com.example.permissionpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PermissionProApplication {

	public static void main(String[] args) {
		SpringApplication.run(PermissionProApplication.class, args);
	}

}
